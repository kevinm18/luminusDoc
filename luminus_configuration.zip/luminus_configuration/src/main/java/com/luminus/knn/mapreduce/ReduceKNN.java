package com.luminus.knn.mapreduce;

import java.io.DataOutputStream;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class ReduceKNN {
	public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
		DataOutputStream stm = null;
		DataOutputStream streamExcel = null;

		protected void setup(Context context) throws IOException, InterruptedException {
			FileSystem fs = FileSystem.get(new Configuration());
			Path escribir = new Path("hdfs:/user/luminus/salidacompleta.txt");
			if (fs.exists(escribir)) {
				fs.delete(escribir, true);
			}
			stm = fs.create(escribir);
		}

		public void reduce(Text word, Iterable<IntWritable> values, Context con)
				throws IOException, InterruptedException {
			String line = word.toString();
			String[] resultado = line.split(",");
			int sum = 0;
			for (IntWritable value : values) {
				sum += value.get();
			}
			stm.writeBytes(line + " aparece: " + sum);
			stm.writeBytes("\n");
			con.write(word, new IntWritable(sum));
		}
	}
}
