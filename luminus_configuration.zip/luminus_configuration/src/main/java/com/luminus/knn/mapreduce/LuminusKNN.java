package com.luminus.knn.mapreduce;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import com.luminus.knn.mapreduce.MapKNN.Map;
import com.luminus.knn.mapreduce.ReduceKNN.Reduce;


public class LuminusKNN {
	public static void main(String[] args) throws Exception {
		Configuration c = new Configuration();
		String[] files = new GenericOptionsParser(c, args).getRemainingArgs();
		Path input = new Path(files[0]); // donde voy a tomar el archivo
		Path output = new Path(files[1]); // donde voy a dejar la salida
		// c.setInt("prueba",5);
		Job j = new Job(c, "wordcount");
		j.setJarByClass(LuminusKNN.class);
		j.setMapperClass(Map.class); // donde esta el map
		j.setReducerClass(Reduce.class); // donde esta el reduce
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(j, input);
		FileOutputFormat.setOutputPath(j, output); // de los argumentos que lei , mi entrada y mi salida
		String valork = "";
		String pathsalidacompleta = "";
		String pathsalidaordenadacompleta = "";
		String pathsalidak = "";
		String pathsalidaexcel = "";
		int numk;
		HashMap<Double, String> puntosobtenidos = new HashMap<Double, String>();
		ArrayList<String> completo = new ArrayList<String>();
		try {
			Properties prop = new Properties();
			Path pt = new Path("hdfs:/user/luminus/configuracion.properties");// Location of file in HDFS
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
			prop.load(br);
			valork = prop.getProperty("K");
			pathsalidacompleta = prop.getProperty("pathsalidacompleta");
			pathsalidaordenadacompleta = prop.getProperty("pathsalidaordenadacompleta");
			pathsalidak = prop.getProperty("pathsalidak");
			pathsalidaexcel = prop.getProperty("pathsalidaexcel");
		} catch (Exception e) {
		}
		numk = Integer.valueOf(valork);
		try {
			// Path pt=new Path("hdfs:/user/luminus/knn2/resumay13/part-r-00000");
			// Path pt=new Path("hdfs:/user/luminus/knn2/salidacompleta.txt");
			Path pt = new Path(pathsalidacompleta);
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
			String linealeida;
			linealeida = br.readLine();
			while (linealeida != null) {
				// System.out.println(line);
				String[] resultado = linealeida.split(",");
				puntosobtenidos.put(Double.parseDouble(resultado[0]), resultado[1]);
				completo.add(linealeida);
				linealeida = br.readLine();// esta leyendo la siguiente
			}
		} catch (Exception e) {
		}
		// double ordenar[] =new double[puntosobtenidos.size()];
		List<Double> ordenar = new ArrayList<Double>();
		// int x=0;
		for (Double n : puntosobtenidos.keySet()) {
			// ordenar[x]=n;
			ordenar.add(n);
			// x++;
		}
		// Arrays.sort(ordenar);
		Collections.sort(ordenar);
		// este es el codigo que escribe en un archivo
		FileSystem fs1 = FileSystem.get(new Configuration());
		Path escribir1 = new Path(pathsalidaordenadacompleta);
		if (fs1.exists(escribir1)) {
			fs1.delete(escribir1, true);
		}

		// Escritura del archivo salidaordenadacompleta.txt.
		DataOutputStream stm1 = fs1.create(escribir1);
		// stm.writeBytes("holi");
		for (int i = 0; i < ordenar.size(); i++) {
			stm1.writeBytes(
					"Distancia: " + ordenar.get(i) + " que corresponde a: " + puntosobtenidos.get(ordenar.get(i)));
			stm1.writeBytes("\n");
		}
		stm1.close();

		FileSystem fs = FileSystem.get(new Configuration());
		Path escribir = new Path(pathsalidak);
		if (fs.exists(escribir)) {
			fs.delete(escribir, true);
		}
		DataOutputStream stm = fs.create(escribir);
		// stm.writeBytes("holi");
		ArrayList<String> elemento = new ArrayList<String>();
		ArrayList<Integer> repite = new ArrayList<Integer>();
		stm.writeBytes("se solicito un k=" + numk + " se listan estos k nodos \n");
		for (int i = 0; i < ordenar.size(); i++) {
			if (i < numk) {
				stm.writeBytes(
						"Distancia: " + ordenar.get(i) + " que corresponde a: " + puntosobtenidos.get(ordenar.get(i)));
				stm.writeBytes("\n");
				String despuesdeclase = puntosobtenidos.get(ordenar.get(i)).substring(
						puntosobtenidos.get(ordenar.get(i)).indexOf("clase"),
						puntosobtenidos.get(ordenar.get(i)).indexOf("aparece:"));
				if (elemento.contains(despuesdeclase)) {
					int value = elemento.indexOf(despuesdeclase);
					int contenido = repite.get(value);
					repite.set(value, contenido + 1);
				} else {
					elemento.add(despuesdeclase);
					repite.add(1);
				}
			}
		}
		int posicion = 0;
		int mayor = -1;
		for (int i = 0; i < elemento.size(); i++) {
			if (repite.get(i) > mayor) {
				posicion = i;
				mayor = repite.get(i);
			}
		}
		// stm.writeBytes("dime algo"+posicion+""+mayor);
		for (int i = 0; i < elemento.size(); i++) {
			if (i == 0) {
				if (mayor == 1) {
					stm.writeBytes("no hay una clase a la que pertenezca ya que los resultados no fueron concluyentes");
				} else {
					stm.writeBytes("pertenece a" + elemento.get(i) + " la cual forma parte de " + mayor + "k cercanos");
				}
			}
		}
		stm.close();
		// j.getConfiguration().setInt("prueba",5);
		/*
		  Generacion del archivo excel
		 */
		FileSystem sistemaExcel = FileSystem.get(new Configuration());
		Path pathArchivoExcel = new Path(pathsalidaexcel);
		if (fs1.exists(pathArchivoExcel)) {
			fs1.delete(pathArchivoExcel, true);
		}
		// Flujo de datos de salida para poder escribir el archivo Excel.
		DataOutputStream streamExcel = sistemaExcel.create(pathArchivoExcel);
		// Mapa en el que se guardaran los datos leidos
		HashMap<Double, String> mapaDatosExcel = new HashMap<Double, String>();
		try {
			// Lectura de cada linea del archivo salidaordenadacompleta.txt
			BufferedReader lectorExcel = new BufferedReader(new InputStreamReader(sistemaExcel.open(escribir1)));
			String filaExcel = lectorExcel.readLine();
			while (filaExcel != null) {
				String [] fila = filaExcel.split(",");
				mapaDatosExcel.put(Double.parseDouble(fila[0]), fila[1]);
				filaExcel = lectorExcel.readLine();
			}
		} catch (Exception e) {

		}
		//Extrae clases
		HashMap<Double, String> puntosObtenidosParaExcel = puntosobtenidos;
//		List<String> listaCoordenadas = new ArrayList<>();
//		List<String> listaClases = new ArrayList<>();
//		List<String> listaVecesQueAparece = new ArrayList<>();
		for (Double puntoSubcadenaClase : puntosObtenidosParaExcel.keySet()) {
			
		}
		// Escritura de cada punto en el archivo salidaexcel.xsl
		streamExcel.writeBytes("Distancia\t Ubicacion\n");
		List<String> subcadenas = new ArrayList<String>();
		for (Double punto : ordenar) {
			subcadenas.add(puntosObtenidosParaExcel.get(punto));
		}
		// Lectura de las subcadenas para obtener los demas resultados
		for (String sub : subcadenas) {
			
		}
		Integer contador = 0;
		for (Double punto : ordenar) {
			streamExcel.writeBytes(punto.toString() + "\t" + subcadenas.get(contador) + "\n");
			contador++;
		}
		streamExcel.close();
		System.exit(j.waitForCompletion(true) ? 0 : 1);
	}
}
