package com.luminus_configuration;


import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;

import com.luminus.exception.LuminusException;


/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Integer k = 2;
		Integer columnas = 13;
		Boolean buscar = false;
		ArrayList<Double> origen = new ArrayList<Double>();
		origen.add(14.2);
		origen.add(13.7);
		ArrayList<Integer> posiciones = new ArrayList<Integer>();
		posiciones.add(14);
		posiciones.add(15);
		String elemento = "\"TLAXCALA                                \"";
		String salidaCompleta = "hdfs:/user/luminus/salidacompleta.txt";
		String salidaOrdenadaCompleta = "hdfs:/user/luminus/salidaordenadacompleta.txt";
		String salidaK = "hdfs:/user/luminus/salidak.txt";
		String salidaExcel = "hdfs:/user/luminus/salidafinal.ods";
		LuminusConfiguration knn = new LuminusConfiguration(k, columnas, buscar, elemento, origen, posiciones, salidaOrdenadaCompleta,
				salidaCompleta, salidaK, salidaExcel);
//		knn.createConfiguration();
		try {
			// knn.getDataFromFile("192.168.0.8:9000", "/user/luminus/prueba.txt", System.out);
			// knn.uploadFileToHDFS("/home/maestroluminuscom/Escritorio/proc.txt", "/user/luminus/");
//			knn.deleteFileFromHDFS("/user/luminus/proc.txt");
//			knn.getDataFromFile("/user/luminus/proc.txt", new FileOutputStream("proc.txt"));
//			System.err.println(knn.existsInHDFS("/user/luminus/proc.txt"));
			//knn.uploadFileToHDFS("/home/maestroluminuscom/Descargas/configuracion.properties", "/user/luminus/configuracion.properties");
		} catch (Exception e) {
			
		}
		// knn.uploadConfigurations();
		 try {
			knn.runKNN();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
